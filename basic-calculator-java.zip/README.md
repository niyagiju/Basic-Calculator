# Basic Calculator (Java Swing)

A simple **Basic Calculator** desktop application built with Java Swing.

## Features
- Addition, Subtraction, Multiplication, Division
- Decimal numbers
- Clear (C)
- Simple GUI built with Swing

## Files
- `Calculator.java` - main Java source file (single-file project)

## How to compile & run (using terminal)
Make sure you have Java (JDK) installed.

```bash
# compile
javac Calculator.java

# run
java Calculator
```

## How to put on GitHub
1. Create a new repository on GitHub (e.g. `basic-calculator-java`).
2. Clone it locally or copy the files into a folder.
3. Add `Calculator.java` and `README.md`.
4. Commit & push:
```bash
git init
git add .
git commit -m "Initial commit - Basic Calculator in Java (Swing)"
git branch -M main
git remote add origin https://github.com/yourusername/basic-calculator-java.git
git push -u origin main
```

Enjoy! 🎉